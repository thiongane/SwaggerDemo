# SwaggerDemo
Demo using Swagger API in ASP.NET Core Web API
